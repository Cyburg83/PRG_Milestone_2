#########################################
		Readme - Milestone 2
#########################################

--Autoren--
Andr� Burg
Luis Hohmann
Chantal Klemm
Arvin Matics

--

--Einf�hrung--
Vorliegender Ordner ist ein QT Projekt, welches durch �ffnen der .pro-Datei in Qt Creator ausgef�hrt werden kann.

--

SNAKE - Manual

Steuerung: Pfeiltasten

Pause: Stop Button

Resume: Start Button

Reset: Clear Button

Man kann zwischen beiden Spielmodi hin- und herwechseln



--Bestehende Probleme zum Zeitpunkt der Abgabe--

Die Aufgabenstellung suggerierte eine Implementierung von Snake mittels CAbase.
In dieser Version wurde Snake jedoch unabh�ngig von CAbase implementiert und besitzt
lediglich eine Schnittstelle zu GameWidget.

Davon abgesehen wurden zum Zeitpunkt der Abgabe keine Probleme festgestellt und alle
Funktionen implementiert.

F�r die Implementierung von Snake sind somit nur snake.h, sowie die
entsprechend kommentierten Anpassungen in gamewidget.h/.cpp und mainwindow.h/.cpp relevant.

