#ifndef SNAKE_H
#define SNAKE_H

#include "cabase.h"

class Snake     // subclass from CAbase
        : public CAbase
{
private:
    struct Segment  // data structure linked list for head, body, tail
    {
        int coords;
        Segment *next;
    };

    Segment *head;
    Segment *tail;

    int gridSize;   // possibly not needed here

    void updateCoords(Segment *current, int newCoords);



    int lastTailPos;    // stores coordinates for appending new segment when eating

public:
    Snake() // might have to be modified
        : gridSize(50)
        , currDirection(6)
    {
        head = NULL;
        tail = NULL;
    }

    ~Snake();

    using CAbase::_evolveCurrent;   //override inherited function
    void _evolveCurrent(int *&curr_grid, int *next_grid) {
        delete [] curr_grid;
        curr_grid = next_grid;
    }

    void append(int xCoord, int yCoord);

    int currDirection;

    void print();

    void moveSnake();

    void snakeToGrid(int *&caGrid);

    void steerSnake(int newDirection);

    int getHead() { return head; }

    bool snakeCollision();

    void evolveSnake();


};

// 'inline' declaration prevents "multiple definition"-error in header

inline void Snake::append(int xCoord, int yCoord)
{
    // append new segment to snake (that will become its tail)
    Segment *newTail = new Segment;
    int newCoords = xCoord + _sizeX*yCoord;
    newTail->coords = newCoords;
    newTail->next = NULL;

    if(head == NULL) {
        tail = head = newTail;
        newTail = NULL;
    }
    else {
        tail->next = newTail;
        tail = newTail;
    }
}



inline void Snake::print()
{
    // not needed for widget
    Segment *current = new Segment;
    current = head;

    while (current != NULL) {
        std::cout << current->coords << "\t";
        current = current->next;
    }
    std::cout << std::endl;
}

inline void Snake::updateCoords(Segment *current, int newCoords)
{
    // recursive;
    // head gets new value
    // all current values get successively passed on to next segment
    lastTailPos = tail->coords;
    int tempCoords = current->coords;
    current->coords = newCoords;
    if (current->next != NULL) {
        write(current->next, tempCoords);
    }
}

inline void Snake::moveSnake()
{
    // initalizes updateCoords with respective newCoords for head
    int headPos = head->coords;
    switch (currDirection) {
    case 2:
        updateCoords(head, headPos + gridSize);
        break;
    case 4:
        updateCoords(head, headPos - 1);
        break;
    case 6:
        updateCoords(head, headPos + 1);
        break;
    case 8:
        updateCoords(head, headPos - gridSize);
    default:
        break;
    }
}

inline void Snake::steerSnake(int newDirection)
{
    // handles direction input (will be triggered by keyPressEvent)
    int headPos = head->coords;
    switch (newDirection) {
    case 2:
        if(currDirection != 8) {
            currDirection = 2;
        }
        break;
    case 4:
        if (currDirection != 6) {
            currDirection = 4;
        }
        break;
    case 6:
        if (currDirection != 4) {
            currDirection = 6;
        }
        break;
    case 8:
        if (currDirection != 2) {
            currDirection = 8;
        }
        break;
    default:
        break;
    }
}

inline bool Snake::snakeCollision()
{
    // to be implemented
    int headPos = head->coords;
}

inline void Snake::snakeToGrid(int* &caGrid)
{
    // fills CAbases' _current with snake segments
    Segment *current = new Segment;
    current = head;

    while (current != NULL) {
        _setAliveCurrentCell(caGrid, current->coords);
        current = current->next;
    }
}

inline void Snake::evolveSnake()
{
    // the evolve function so far
    snakeToGrid(_current);
    moveSnake();
    snakeToGrid(_next);
    _evolveCurrent(_current, _next);
}



#endif // SNAKE_H
