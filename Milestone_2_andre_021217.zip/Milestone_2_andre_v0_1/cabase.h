#ifndef CABASE_H
#define CABASE_H


#include <iostream>

class CAbase {

public:
    CAbase(int Nx, int Ny) {        //Constructor
        std::cout << "CAbase was instantiated" << std::endl;
        _current = new int[Nx * Ny];
        _next = new int[Nx * Ny];
        _currentView = new char[Nx * Ny];
        _nextView = new char[Nx * Ny];
        _sizeX = Nx;
        _sizeY = Ny;
        for (int i = 0; i < (Nx * Ny); i++){
                _current[i] = 0;
                _next[i]= 0;

                _currentView[i] = ' ';
                _nextView[i] = ' ';
        }
    }

    ~CAbase() {
        std::cout << "CAbase was destroyed" << std::endl;
        delete[] _current;
        delete[] _next;
        delete[] _currentView;
        delete[] _nextView;
    }

    void printCurrentView();
    void resizeGrid(int Nx, int Ny);
    void setAliveCell(int x_coord, int y_coord);
    void evolveGrid();
    void clearAllCells();
    bool cellIsAlive(int xCoord, int yCoord);

    int* get_current();
    int* get_next();
    int get_size();
    int get_neighbours(int cell_x, int cell_y);

protected:
    // universe size
    int _sizeX;
    int _sizeY;
    // universe model
    int* _current;
    int* _next;
    // universe view
    char* _currentView;
    char* _nextView;

    void _printGrid(char* grid, int sizeX, int sizeY);
    void _resizeGrid(int* &grid, char* &grid_view, int Nx, int Ny);
    void _getView(char *&grid_view, int *grid, int Nx, int Ny);
    int _getNeighbours(int* grid, int cell, int sizeX, int sizeY);
    void _setAliveCurrentCell(int* &grid, int cell);
    void _setNextCell(int* &next_grid, int* curr_grid, int cell, int neighbours);
    void _setAllNextCells(int* &grid, int sizeX, int sizeY);
    void _evolveCurrent(int* &curr_grid, int* next_grid, int sizeX, int sizeY);
    void _clearGrid(int* &grid, int sizeX, int sizeY);








};


inline void CAbase::printCurrentView() {
    // updates grid view from grid model and prints it
    _getView(_currentView, _current, _sizeX, _sizeY);
    _printGrid(_currentView, _sizeX, _sizeY);
}


inline void CAbase::resizeGrid(int Nx, int Ny) {
    // change size of grid models and grid views
    _resizeGrid(_current, _currentView, Nx, Ny);
    _resizeGrid(_next, _nextView, Nx, Ny);

    // new sizes are allocated
    _sizeX = Nx;
    _sizeY = Ny;

    // next evolution step is computed again
    _setAllNextCells(_next, _sizeX, _sizeY);
}


inline void CAbase::setAliveCell(int x_coord, int y_coord){
    // Current model cell is set to 'alive' at given coordinates
    int cell = x_coord + y_coord * _sizeX;
    _setAliveCurrentCell(_current, cell);
    // Next model is updated accordingly
    _setAllNextCells(_next, _sizeX, _sizeY);
}


inline void CAbase::evolveGrid(){
    // Current model is overwritten with Next model
    _evolveCurrent(_current, _next, _sizeX, _sizeY);
    // Next model is updated accordingly
    _setAllNextCells(_next, _sizeX, _sizeY);
}


inline void CAbase::clearAllCells() {
    // sets all cells to 0, called in GameWidget::clear()
    _clearGrid(_current, _sizeX, _sizeY);
    // Next model is updated accordingly
    _setAllNextCells(_next, _sizeX, _sizeY);
}


inline bool CAbase::cellIsAlive(int xCoord, int yCoord) {
    // Called in GameWidget::paintUniverse,
    // checks living cells and updates widget grid view accordingly
    int cell = xCoord + yCoord * _sizeX;
    if (_current[cell] == 1) {
        return true;
    } else{
        return false;
    }
}


inline int* CAbase::get_current() {
    // returns current array
    return _current;
}


inline int* CAbase::get_next() {
    // for debugging purposes only
    return _next;
}


inline int CAbase::get_size() {
    // returns current grid size (of square grid)
    return _sizeX;
}


inline int CAbase::get_neighbours(int cell_x, int cell_y) {
    // counts and returns neighbours of given cell
    int cell = cell_x + _sizeX*cell_y;
    return _getNeighbours(_current, cell, _sizeX, _sizeY);
}

//private methods
inline void CAbase::_printGrid(char* grid, int sizeX, int sizeY) {
    // prints grid view
    //std::cout << "_printGrid called" << std::endl;
    for (int i = 0; i <= sizeX+1; i++) {
        std::cout << ". ";
    }
    std::cout << std::endl;
    for (int i = 0; i < sizeX * sizeY; i++) {
        if(i == 0) {
            std::cout << ". ";
        }
        if (i % sizeX == 0 && i>0) {
            std::cout << "." << std::endl << ". ";
        }
        std::cout << grid[i] << " ";
    }
    std::cout << "." << std::endl;
    for (int i = 0; i <= sizeX+1; i++) {
        std::cout << ". ";
    }
    std::cout << std::endl;
}


inline void CAbase::_resizeGrid(int* &grid, char* &grid_view, int Nx, int Ny) {
    // de-/increase current grid size
    //std::cout << "_resize called" << std::endl;
    int* temp = new int[Nx * Ny];
    char* temp_view = new char[Nx * Ny];
    if (Nx * Ny > _sizeX * _sizeY) {          // if increase size
        for (int i=0; i < Nx*Ny; i++) {
            temp[i] = 0;
            temp_view[i] = ' ';
        }
        for (int j=0; j < _sizeY; j++) {
            for (int i=0; i < _sizeX; i++) {
                temp[i + j*Nx] = grid[i + j*_sizeX];
                temp_view[i + j*Nx] = grid_view[i + j*_sizeX];
            }
        }
    } else {                                    // if decrease size
        for (int j = 0; j < Ny; j++) {
            for (int i = 0; i < Nx; i++) {
                temp[i + j*Nx] = grid[i + j*_sizeX];
                temp_view[i + j*Nx] = grid_view[i + j*_sizeX];
            }
        }
    }

    delete [] grid;
    grid = temp;

    delete [] grid_view;
    grid_view = temp_view;
}


// private Getters

inline void CAbase::_getView(char *&grid_view, int *grid, int Nx, int Ny) {
    // updates grid view from grid model
    //std::cout << "_getView called" << std::endl;
    char* temp = new char[Nx * Ny];
    for (int i = 0; i < Nx * Ny; i++) {
        temp[i] = grid[i] == 0 ? ' ' : '*';
    }

    delete[] grid_view;
    grid_view = temp;
}


inline int CAbase::_getNeighbours(int* grid, int cell, int sizeX, int sizeY) {
    // iterates and counts living neighbours of given cell
    // ternary operator '?' handles boundary checks
    int neighbours = 0;

    for (int dim_x = (cell%sizeX != 0 ? -1 : 0); dim_x <= (cell%sizeX < (sizeX-1) ? 1 : 0); dim_x++) {
        for (int dim_y = (cell/sizeY != 0 ? -1 : 0); dim_y <= (cell/sizeY < (sizeY-1) ? 1 : 0); dim_y++) {
            if (dim_x != 0 || dim_y != 0) {
                neighbours += grid[cell + dim_x + dim_y*_sizeY];
            }
        }

    }
    return neighbours;
}


//private Setters

inline void CAbase::_setAliveCurrentCell(int* &grid, int cell) {
    // sets given cell to 'alive'
    //std::cout << "_populateCell called" << std::endl;
    grid[cell] = 1;
}


inline void CAbase::_setNextCell(int* &next_grid, int* curr_grid, int cell, int neighbours) {
    //std::cout << "_setCell called" << std::endl;
    // computes state of given cell in next evolution step according to game rules
    switch(neighbours) {
    case 2:
        next_grid[cell] = curr_grid[cell] == 1 ? 1 : 0;
        break;
    case 3: next_grid[cell] = 1;
        break;
    default:
        next_grid[cell] = 0;
        break;
    }
}


inline void CAbase::_setAllNextCells(int* &grid, int sizeX, int sizeY) {
    //std::cout << "_setNext called" << std::endl;
    // computes state of all cells in next evolution step according to game rules
    for(int i=0; i < sizeX * sizeY; i++){
        int neighbours = _getNeighbours(_current, i, sizeX, sizeY);
        _setNextCell(grid, _current, i, neighbours);
    }
}


inline void CAbase::_evolveCurrent(int* &curr_grid, int* next_grid, int sizeX, int sizeY) {
    //std::cout << "_updateCurrent called" << std::endl;
    // overwrites current grid model with next grid model
    int* temp = new int[sizeX * sizeY];
    for (int i=0; i < sizeX*sizeY; i++) {
        temp[i] = next_grid[i];
    }
    delete [] curr_grid;
    curr_grid = temp;
}

inline void CAbase::_clearGrid(int* &grid, int sizeX, int sizeY) {
    for (int cell = 0; cell< sizeX*sizeY; cell++) {
        grid[cell] = 0;
    }
}

#endif // CABASE_H
