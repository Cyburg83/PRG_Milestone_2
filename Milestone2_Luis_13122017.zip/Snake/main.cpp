#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <conio.h>
#include <stdlib.h>
#include "Snake.h"


int main() {
    int dir = 8;
    Snake snakeGame(20,20);

    snakeGame.print();

    // Loop for running game
    while(true){
        // delay for better vizualisation
        _sleep(200);
        // checks for keyboard hit
        if(_kbhit()){
            switch (_getch()) {
            case '2':
                snakeGame.setDirection(2);
                break;
            case '8':
                snakeGame.setDirection(8);
                break;
            case '4':
                snakeGame.setDirection(4);
                break;
            case '6':
                snakeGame.setDirection(6);
                break;
            }
        }
        // remove old grid in console
        system("CLS");

        // move snake and check if snake crashed
        if (snakeGame.move()){
            // print grid if snake is alive
            snakeGame.print();
        }else{
            // stop loop if snake crashed
            break;
        }
    }

    // text at the end of the game
    std::cout << std::endl << "===========================" << std::endl;
    std::cout << "         Game Over!" << std::endl;
    std::cout << "===========================" << std::endl;

    // destroy instance of Snake
    snakeGame.~Snake();

    // keep console window open
    system("PAUSE");
    return 0;
}
