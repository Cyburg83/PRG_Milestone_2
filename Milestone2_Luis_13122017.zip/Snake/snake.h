#ifndef SNAKE_H
#define SNAKE_H

class Snake{

public:

    Snake(int Nx, int Ny){
        /* - Nx and Ny for grid size
         * - static integer array for grid
         *   (Cell: 0 -> empty, 1 -> head, 2 -> body, 3 -> tail, 4 -> food)*/
        _size_x = Nx;
        _size_y = Ny;
        _clear();
        _setSnake();
        _setFood();
    }

    ~Snake(){
        delete[] _grid;
        delete[] _body;
    }

    bool move(){
        // Moves snake's head. Body and tail follow. Returns false, if snake crashs.
        // (2 – down, 8 - up, 4 - left, 6 – right)

        // delete head on grid
        int head_cell = _coordToCell(_head.x, _head.y);
        _grid[_coordToCell(_head.x, _head.y)] = 0;

        // delete body sections on grid
        for(int i = 0; i < _length; i++){
            _grid[_coordToCell(_body[i].x, _body[i].y)] = 0;
        }

        // delete tail on grid
        _grid[_coordToCell(_tail.x, _tail.y)] = 0;

        // save old_tail
        section old_tail = _tail;

        // set tail to last body element
        _tail = _body[_length-1];

        // set tail on grid
        _grid[_coordToCell(_tail.x, _tail.y)] = 3;

        // set body sections to fore sections and set them on the grid
        for(int i = _length-1; i > 0; i--){
            _body[i] = _body[i-1];
            _grid[_coordToCell(_body[i].x, _body[i].y)] = 2;
        }
        // set first body section to head
        _body[0] = _head;

        // set first body section on grid
        _grid[_coordToCell(_body[0].x, _body[0].y)]=2;


        // move head to the given direction
        switch (_dir){
        case 2:
            // check for border crash
            if(_head.y == _size_y-1){
                return false;
            } else {
                // check for food
                if(_grid[_getLower(_head.x, _head.y)] == 4){
                    // stretch snake's body
                    _body[_length]=_tail;
                    _grid[_coordToCell(_body[_length].x, _body[_length].y)]=2;
                    _tail = old_tail;
                    _grid[_coordToCell(_tail.x, _tail.y)]=3;
                    _length = _length + 1;
                    // set new food
                    _setFood();
                }
                // check for snake crash
                if((_grid[_getLower(_head.x, _head.y)] == 2)||(_grid[_getLower(_head.x, _head.y)] == 3)){
                    return false;
                }
                // move head
                _head.y++;
                _grid[head_cell+_size_x]=1;
            }
            break;
        case 8:
            if (_head.y == 0){
                return false;
            } else {
                // check for food
                if(_grid[_getUpper(_head.x, _head.y)] == 4){
                    // stretch snake's body
                    _body[_length]=_tail;
                    _grid[_coordToCell(_body[_length].x, _body[_length].y)]=2;
                    _tail = old_tail;
                    _grid[_coordToCell(_tail.x, _tail.y)]=3;
                    _length = _length + 1;
                    // set new food
                    _setFood();
                }
                // check for snake crash
                if((_grid[_getUpper(_head.x, _head.y)] == 2)||(_grid[_getUpper(_head.x, _head.y)] == 3)){
                    return false;
                }
                // move head
                _head.y--;
                _grid[head_cell-_size_x]=1;
            }
            break;
        case 4:
            if (_head.x == 0){
                return false;
            } else {
                // check for food
                if(_grid[_getLeft(_head.x, _head.y)] == 4){
                    // stretch snake's body
                    _body[_length]=_tail;
                    _grid[_coordToCell(_body[_length].x, _body[_length].y)]=2;
                    _tail = old_tail;
                    _grid[_coordToCell(_tail.x, _tail.y)]=3;
                    _length = _length + 1;
                    // set new food
                    _setFood();
                }
                // check for snake crash
                if((_grid[_getLeft(_head.x, _head.y)] == 2)||(_grid[_getLeft(_head.x, _head.y)] == 3)){
                    return false;
                }
                // move head
                _head.x--;
                _grid[head_cell-1]=1;
            }
            break;
        case 6:
            if (_head.x == _size_x-1){
                return false;
            }else{
                // check for food
                if(_grid[_getRight(_head.x, _head.y)] == 4){
                    // stretch snake's body
                    _body[_length]=_tail;
                    _grid[_coordToCell(_body[_length].x, _body[_length].y)]=2;
                    _tail = old_tail;
                    _grid[_coordToCell(_tail.x, _tail.y)]=3;
                    _length = _length + 1;
                    // set new food
                    _setFood();
                }
                // check for snake crash
                if((_grid[_getRight(_head.x, _head.y)] == 2)||(_grid[_getRight(_head.x, _head.y)] == 3)){
                    return false;
                }
                // move head
                _head.x++;
                _grid[head_cell+1]=1;
            }
            break;
        }
        return true;
    }



    // --- Public Setters ---

    void setDirection(int dir){
        // Set snakes slither direction to:
        // 2 – down, 8 - up, 4 - left, 6 – right
        // Function does not change the direction,
        //if the given direction is the opposite of
        // the actual direction.
        switch(_dir){
        case 2: if(dir != 8){_dir = dir;} break;
        case 8: if(dir != 2){_dir = dir;} break;
        case 4: if(dir != 6){_dir = dir;} break;
        case 6: if(dir != 4){_dir = dir;} break;
        }
    }

    void resizeGrid(int Nx, int Ny){
        // Sets size of grid to given size.
        _size_x = Nx;
        _size_y = Ny;
        _clear();
        _setFood();
        _grid[_coordToCell(_head.x, _head.y)]=1;
        _grid[_coordToCell(_tail.x, _tail.y)]=3;
        for (int i = 0; i < _length; i++){
            _grid[_coordToCell(_body[i].x, _body[i].y)]=2;
        }
    }



    void reset(){
        // Clears grid and resets snake.
        _clear();
        _length = 1;
        _setSnake();
    }


    // --- Public Getters ---

    void print(){
        // Prints the grid on console.
        for (int i = 0; i <= _size_x+1; i++) {
            std::cout << ". ";
        }
        std::cout << std::endl;

        for (int i = 0; i < _size_x * _size_y; i++) {
            if(i == 0) {
                std::cout << ". ";
            }
            if (i % _size_x == 0 && i>0) {
                std::cout << "." << std::endl << ". ";
            }

            switch (_grid[i]){
            case 0: std::cout << "  "; break;
            case 1: std::cout << "O "; break;
            case 2: std::cout << "# "; break;
            case 3: std::cout << "X "; break;
            case 4: std::cout << "* "; break;
             }
        }
        std::cout << "." << std::endl;
        for (int i = 0; i <= _size_x+1; i++) {
            std::cout << ". ";
        }
        std::cout << std::endl;
    }


private:
    // --- Private Variables ---

    // Universe: Grid Size
    int _size_x;
    int _size_y;
    // Universe: Grid
    int _grid[2499];

    // Snake: Direction
    int _dir;
    // Snake: Length
    int _length = 1;
    // Snake: Sections of Snake
    struct section {
        int x;
        int y;
    };
    // Snake: head and tail
    section _head;
    section _tail;
    // Snake: array of sections as body
    section _body[2497];

    // Food
    int _food;



    // --- Private Setters ---

    void _setSnake(){
        // Places the snake in the middle of the grid. Looking upward.
        _dir = 8;
        _head.x = _size_x/2;
        _head.y = _size_y/2;

        _body[0].x = _size_x/2;
        _body[0].y = _size_y/2+1;

        _tail.x = _size_x/2;
        _tail.y = _size_y/2+2;

        _grid[_coordToCell(_size_x/2, _size_y/2)] = 1;
        _grid[_coordToCell(_size_x/2, _size_y/2+1)] = 2;
        _grid[_coordToCell(_size_x/2, _size_y/2+2)] = 3;
    }

    void _setFood(){
        // Sets food on random coordinates.
        srand(time(NULL));
        _grid[_coordToCell(rand() % _size_x, rand() % _size_y)] = 4;
    }

    void _setFood(int x, int y){
        // Sets food on given coordinates.
        _grid[_coordToCell(x, y)] = 4;
    }



    // --- Private Getters ---

    int _getLower(int x_coord, int y_coord){
        // Returns cell value (position in 1D array) of the lower element.
        return _coordToCell(x_coord, y_coord+1);
    }

    int _getUpper(int x_coord, int y_coord){
        // Returns cell value (position in 1D array) of the upper element.
        return _coordToCell(x_coord, y_coord-1);
    }

    int _getLeft(int x_coord, int y_coord){
        // Returns cell value (position in 1D array) of the left element.
        return _coordToCell(x_coord-1, y_coord);
    }

    int _getRight(int x_coord, int y_coord){
        // Returns cell value (position in 1D array) of the right element.
        return _coordToCell(x_coord+1, y_coord);
    }

    int _coordToCell(int x, int y){
        // Converts coordinates of an element to the position in
        // 1-D array (called 'cell').
        return (y * _size_x + x);
    }



    // --- Private Getters ---

    void _clear(){
        // Clears the grid.
        for (int i = 0; i < (_size_x * _size_y); i++){
                _grid[i] = 0;
        }
    }

};
#endif // SNAKE_H
