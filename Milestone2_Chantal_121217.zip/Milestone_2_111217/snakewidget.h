#ifndef SNAKEWIDGET_H
#define SNAKEWIDGET_H

#include <QWidget>
#include <QTimer>
#include <QFrame>
#include <QPointer>
#include <QColor>
#include <QFileDialog>
#include <QGraphicsScene>
#include <QFile>
#include <QDataStream>

class CAbase;
class snake;

class SnakeWidget : public QWidget
{
    Q_OBJECT

public:
    SnakeWidget(QWidget *parent = 0);

public slots:
    void saveToFile(QFile &file);
    void loadFromFile(QFile &file);

    void startGame();
    void stopGame();
    void clear();

    void newGeneration();

    void setTimerInterval(int interval);

    void setUniverseSize(int newSize);

    QColor defaultColor(); // cell color
    void setdefaultColor(const QColor &color);

    int getUniverseSize();
//    void selectGame();


protected:
    void paintEvent(QPaintEvent *);
    void keyPressEvent(QKeyEvent *event) override;


private slots:
    void paintGrid(QPainter &p, QRect &rect, int gridWidth, int gridHeight, int cellWidth, int cellHeight);
    void paintCell(const QPoint &lastCell);
    void paintUniverse(QPainter &p, CAbase *cabase);

private:
    int universeSize;
    snake *snake1;
    QColor m_defaultColor;
    QTimer *timer;

    int cellWidth;
    int cellHeight;

    int gridWidth;
    int gridHeight;

    bool modified;
    QPoint currentCell;

};


#endif // SNAKEWIDGET_H
