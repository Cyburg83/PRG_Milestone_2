#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QColor>
#include <QFileDialog>
#include <QFile>
#include <QDataStream>
#include <QMessageBox>

class GameWidget;
class SnakeWidget;

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();


public slots:
    //void selectdefaultColor();
    //void selectrandomColor();
    //void returnValue(int i);
//    void saveGame();
//    void loadGame();

private:
    Ui::MainWindow *ui;
    QColor currentColor;
    GameWidget* game;
    SnakeWidget* snakegame;

private slots:            // Erklärung: Hier kommen die Slot Funktionen rein (Slot = Empfänger eines Signals)
    // most of these are currently empty placeholders
    void on_spinBox_generation_interval_valueChanged(int interval);
    void on_pushButton_start_clicked();
    void on_pushButton_stop_clicked();
    void on_pushButton_clear_clicked();
    void on_spinBox_universe_size_valueChanged(int size);
    void on_pushButton_select_color_clicked();
    void on_pushButton_random_color_clicked();
    void on_pushButton_go_clicked();
    void on_pushButton_load_clicked();
    void on_pushButton_save_clicked();
    void on_comboBox_universe_mode_currentIndexChanged(const QString &arg1);
};

#endif // MAINWINDOW_H
