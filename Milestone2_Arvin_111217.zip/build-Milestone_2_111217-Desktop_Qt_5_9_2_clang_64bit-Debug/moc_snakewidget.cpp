/****************************************************************************
** Meta object code from reading C++ file 'snakewidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../Milestone_2_111217/snakewidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'snakewidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_SnakeWidget_t {
    QByteArrayData data[32];
    char stringdata0[313];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SnakeWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SnakeWidget_t qt_meta_stringdata_SnakeWidget = {
    {
QT_MOC_LITERAL(0, 0, 11), // "SnakeWidget"
QT_MOC_LITERAL(1, 12, 10), // "saveToFile"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 6), // "QFile&"
QT_MOC_LITERAL(4, 31, 4), // "file"
QT_MOC_LITERAL(5, 36, 12), // "loadFromFile"
QT_MOC_LITERAL(6, 49, 9), // "startGame"
QT_MOC_LITERAL(7, 59, 8), // "stopGame"
QT_MOC_LITERAL(8, 68, 5), // "clear"
QT_MOC_LITERAL(9, 74, 13), // "newGeneration"
QT_MOC_LITERAL(10, 88, 16), // "setTimerInterval"
QT_MOC_LITERAL(11, 105, 8), // "interval"
QT_MOC_LITERAL(12, 114, 15), // "setUniverseSize"
QT_MOC_LITERAL(13, 130, 7), // "newSize"
QT_MOC_LITERAL(14, 138, 12), // "defaultColor"
QT_MOC_LITERAL(15, 151, 15), // "setdefaultColor"
QT_MOC_LITERAL(16, 167, 5), // "color"
QT_MOC_LITERAL(17, 173, 15), // "getUniverseSize"
QT_MOC_LITERAL(18, 189, 9), // "paintGrid"
QT_MOC_LITERAL(19, 199, 9), // "QPainter&"
QT_MOC_LITERAL(20, 209, 1), // "p"
QT_MOC_LITERAL(21, 211, 6), // "QRect&"
QT_MOC_LITERAL(22, 218, 4), // "rect"
QT_MOC_LITERAL(23, 223, 9), // "gridWidth"
QT_MOC_LITERAL(24, 233, 10), // "gridHeight"
QT_MOC_LITERAL(25, 244, 9), // "cellWidth"
QT_MOC_LITERAL(26, 254, 10), // "cellHeight"
QT_MOC_LITERAL(27, 265, 9), // "paintCell"
QT_MOC_LITERAL(28, 275, 8), // "lastCell"
QT_MOC_LITERAL(29, 284, 13), // "paintUniverse"
QT_MOC_LITERAL(30, 298, 7), // "CAbase*"
QT_MOC_LITERAL(31, 306, 6) // "cabase"

    },
    "SnakeWidget\0saveToFile\0\0QFile&\0file\0"
    "loadFromFile\0startGame\0stopGame\0clear\0"
    "newGeneration\0setTimerInterval\0interval\0"
    "setUniverseSize\0newSize\0defaultColor\0"
    "setdefaultColor\0color\0getUniverseSize\0"
    "paintGrid\0QPainter&\0p\0QRect&\0rect\0"
    "gridWidth\0gridHeight\0cellWidth\0"
    "cellHeight\0paintCell\0lastCell\0"
    "paintUniverse\0CAbase*\0cabase"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SnakeWidget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   84,    2, 0x0a /* Public */,
       5,    1,   87,    2, 0x0a /* Public */,
       6,    0,   90,    2, 0x0a /* Public */,
       7,    0,   91,    2, 0x0a /* Public */,
       8,    0,   92,    2, 0x0a /* Public */,
       9,    0,   93,    2, 0x0a /* Public */,
      10,    1,   94,    2, 0x0a /* Public */,
      12,    1,   97,    2, 0x0a /* Public */,
      14,    0,  100,    2, 0x0a /* Public */,
      15,    1,  101,    2, 0x0a /* Public */,
      17,    0,  104,    2, 0x0a /* Public */,
      18,    6,  105,    2, 0x08 /* Private */,
      27,    1,  118,    2, 0x08 /* Private */,
      29,    2,  121,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   11,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::QColor,
    QMetaType::Void, QMetaType::QColor,   16,
    QMetaType::Int,
    QMetaType::Void, 0x80000000 | 19, 0x80000000 | 21, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,   20,   22,   23,   24,   25,   26,
    QMetaType::Void, QMetaType::QPoint,   28,
    QMetaType::Void, 0x80000000 | 19, 0x80000000 | 30,   20,   31,

       0        // eod
};

void SnakeWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        SnakeWidget *_t = static_cast<SnakeWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->saveToFile((*reinterpret_cast< QFile(*)>(_a[1]))); break;
        case 1: _t->loadFromFile((*reinterpret_cast< QFile(*)>(_a[1]))); break;
        case 2: _t->startGame(); break;
        case 3: _t->stopGame(); break;
        case 4: _t->clear(); break;
        case 5: _t->newGeneration(); break;
        case 6: _t->setTimerInterval((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->setUniverseSize((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: { QColor _r = _t->defaultColor();
            if (_a[0]) *reinterpret_cast< QColor*>(_a[0]) = std::move(_r); }  break;
        case 9: _t->setdefaultColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 10: { int _r = _t->getUniverseSize();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 11: _t->paintGrid((*reinterpret_cast< QPainter(*)>(_a[1])),(*reinterpret_cast< QRect(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])),(*reinterpret_cast< int(*)>(_a[5])),(*reinterpret_cast< int(*)>(_a[6]))); break;
        case 12: _t->paintCell((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 13: _t->paintUniverse((*reinterpret_cast< QPainter(*)>(_a[1])),(*reinterpret_cast< CAbase*(*)>(_a[2]))); break;
        default: ;
        }
    }
}

const QMetaObject SnakeWidget::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_SnakeWidget.data,
      qt_meta_data_SnakeWidget,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *SnakeWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SnakeWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_SnakeWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int SnakeWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 14)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 14;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
