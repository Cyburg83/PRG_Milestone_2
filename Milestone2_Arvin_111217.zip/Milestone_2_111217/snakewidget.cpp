#include <QtWidgets>

#include <QMouseEvent>
#include "snakewidget.h"
#include <iostream>
#include <QFrame>
#include <QPainter>
//#include "cabase.h"
#include "snake.h"

// Constructor
SnakeWidget::SnakeWidget(QWidget *parent) :
QWidget(parent),
universeSize(30),
snake1(new snake(universeSize, universeSize)),
timer(new QTimer(this))
{
    // some defaults
    setAttribute(Qt::WA_StaticContents);
//    drawing = false;
    modified = false; // this serves currently no purpose
    timer->setInterval(100);
    connect(timer, SIGNAL(timeout()), this, SLOT(newGeneration()));
    setFocusPolicy(Qt::StrongFocus);


}


void SnakeWidget::paintEvent(QPaintEvent *)
{
    // gets reset every turn, the changes are stored in cabase object
    QPainter p(this);

    int cellWidth = width()/universeSize;
    int cellHeight = height()/universeSize;
    int gridWidth = universeSize*cellWidth - 1;
    int gridHeight = universeSize*cellHeight - 1;

    QRect rect(0 ,0 , gridWidth, gridHeight);

    paintGrid(p,rect, gridWidth, gridHeight, cellWidth, cellHeight);
    paintUniverse(p, snake1);
}

void SnakeWidget::paintGrid(QPainter &p, QRect &rect, int gridWidth, int gridHeight, int cellWidth, int cellHeight)
{
    // draws grid on QRect object in paintevent
    QColor gridColor = m_defaultColor;
    p.setPen(gridColor);
    for(int k = cellWidth; k <= gridWidth; k += cellWidth)
        p.drawLine(k, 0, k, gridHeight);

    for(int k = cellHeight; k <= gridHeight; k += cellHeight)
        p.drawLine(0, k, gridWidth, k);
    p.drawRect(rect);
}

void SnakeWidget::paintCell(const QPoint &lastCell)
{
    // width/height, although declared in paintevent AND as private attributes,
    // have to either be passed as arguments or declared within function in order to make this work...
    int cellWidth = width()/universeSize;
    int cellHeight = height()/universeSize;

    int xCoord = currentCell.x() / cellWidth;
    int yCoord = currentCell.y() / cellHeight;

    snake1->setAliveCell(xCoord, yCoord);
    modified = true;
    currentCell = lastCell; // this here is crucial in order to paint multiple cells...

    update();
}

void SnakeWidget::paintUniverse(QPainter &p, CAbase *cabase)
{
    // again, these two need to be declared herein to make this work...
    int cellWidth = width()/universeSize;
    int cellHeight = height()/universeSize;

    QColor pencolor = m_defaultColor;
    p.setPen(pencolor);
    p.setBrush(pencolor);

    // checks each cabase cell, and fills grid view accordingly
    // iterates through entire *array for each update, so not super efficient...
    for (int x = 0; x<universeSize; x++){
        for (int y = 0; y<universeSize; y++) {
            if (snake1->cellIsAlive(x, y)) {
                int xCoord = x * cellWidth;
                int yCoord = y * cellHeight;
                p.fillRect(xCoord, yCoord, cellWidth, cellHeight, pencolor);
            }
        }
    }
    update();


}


QColor SnakeWidget::defaultColor()
{
    //get default color
    return m_defaultColor;
}

void SnakeWidget::setdefaultColor(const QColor &color)
{
    // set default color
    m_defaultColor = color;
    update();
}

void SnakeWidget::startGame() {
    // triggers timer event
    timer->start();

}

void SnakeWidget::stopGame() {
    // stops timer event
    timer->stop();

}

void SnakeWidget::clear(){
    // set all cabase cells to 'dead'
    timer->stop();
    snake1->clearAllCells();
}

void SnakeWidget::newGeneration(){
    // calls cabase evolve function
    snake1->movesnake(2, false);
}

void SnakeWidget::setTimerInterval(int interval){
    // sets timer interval
    timer->setInterval(interval);

}


void SnakeWidget::setUniverseSize(int newSize){
    // calls cabase resize function
    universeSize = newSize;
    snake1->resizeGrid(universeSize, universeSize);

}

void SnakeWidget::saveToFile(QFile &file)
{
    // save current universe size and state of cabase array to file
    int currentSize = universeSize;
    QString currentUniverseSize = QString::number(currentSize);
    int* currentState = snake1->get_current();
    QDataStream out(&file);
    out.setVersion(QDataStream::Qt_4_5);
    out << QString(currentUniverseSize);
    for (int x=0; x<universeSize*universeSize; x++) {
        out << (qint32)currentState[x];
    }
}


void SnakeWidget::loadFromFile(QFile &file)
{
    // overwrite universe size and current state with load data

    snake1->clearAllCells();   // clear existing cabase state

    QDataStream in(&file);
    in.setVersion(QDataStream::Qt_4_5);


    QString loadUniverseSize; // gets assigned to stored size

    in >> loadUniverseSize;
    setUniverseSize(loadUniverseSize.toInt()); // size is overwritten

    qint32* loadCurrentState = new qint32[universeSize*universeSize]; // assignment of stored cabase

    for (int x=0; x<universeSize*universeSize; x++) {
        in >> loadCurrentState[x];
    }

    //cabase state is restored, cell by cell
    for (int x = 0; x < universeSize; x++){
        for (int y = 0; y < universeSize; y++){
            if ((int)loadCurrentState[x+y*universeSize] == 1) {
                snake1->setAliveCell(x, y);
            }
        }
    }
    update();

}

int SnakeWidget::getUniverseSize()
{
    // needed to assign universeSize to respective spinbox after loading file
    return universeSize;
}

//controls the snake
void SnakeWidget::keyPressEvent(QKeyEvent *event)
{
    bool gameover;
    if (gameover == false) {
        SnakeWidget::keyPressEvent(event);
        return;
    }

    switch (event->key()) {
    case Qt::Key_4:
        snake1->movesnake(4, false);
        break;
    case Qt::Key_6:
        snake1->movesnake(6, false);
        break;
    case Qt::Key_2:
        snake1->movesnake(2, false);
        break;
    case Qt::Key_8:
        snake1->movesnake(8, false);
        break;
    case Qt::Key_Space:
        stopGame();
        break;
    default:
        QWidget::keyPressEvent(event);
    }
}
