#ifndef SNAKE_H
#define SNAKE_H

#include <iostream>
#include <limits>
#include <time.h>
#include "cabase.h"

class snake
        : public CAbase
{

public:
    snake(int Nx, int Ny) : CAbase(Nx, Ny) {        //Constructor
        std::cout << "snake" << std::endl;
        _current = new int[Nx * Ny];
        _next = new int[Nx * Ny];
        _currentView = new char[Nx * Ny];
        _nextView = new char[Nx * Ny];
        _size_x = Nx;
        _size_y = Ny;
        _head = Nx*Ny/2 + Nx/2 + 1;
        _size_body = 0;
        _body = new int[0];
        _body[0] = _head-1;
        _tail = _head-2;
        _food = rand() % (_size_x * _size_y);
        _last_direction = 6;
        prepareFieldSnake(_head, _tail, _body, _food);

    }


    // Destructor

    ~snake() {
        delete[] _current;
        delete[] _next;
        delete[] _currentView;
        delete[] _nextView;
        delete[] _body;
    }

    void prepareFieldSnake(int head, int tail, int* body, int food){
        for (int i = 0; i < (_size_x * _size_y); i++){
                _current[i] = 0;
                _next[i]= 0;

                _currentView[i] = ' ';
                _nextView[i] = ' ';

        }
        _current[head] = 1;
        _currentView[head] = '*';

        _current[tail] = 1;
        _currentView[tail] = '*';

        _current[body[0]] = 1;
        _currentView[body[0]] = '*';

        _current[food] = 1;
        _currentView[food] = '*';
    }

    // View
    void printCurrentView() {
        // updates grid view from grid model and prints it
        _getView(_currentView, _current, _size_x, _size_y);
        _printGrid(_currentView, _size_x, _size_y);
    }


    // public Setters
    void resizeGrid(int Nx, int Ny) {
        // change size of grid models and grid views
        _resizeGrid(_current, _currentView, Nx, Ny);
        _resizeGrid(_next, _nextView, Nx, Ny);

        // new sizes are allocated
        _size_x = Nx;
        _size_y = Ny;

        // next evolution step is computed again
        _setAllNextCells(_next, _size_x, _size_y);
    }


    void setAliveCell(int x_coord, int y_coord){
        // Current model cell is set to 'alive' at given coordinates
        int cell = x_coord + y_coord * _size_x;
        _setAliveCurrentCell(_current, cell);
        // Next model is updated accordingly
        _setAllNextCells(_next, _size_x, _size_y);
    }
    void evolveGrid(){
        // Current model is overwritten with Next model
        _evolveCurrent(_current, _next, _size_x, _size_y);
        // Next model is updated accordingly
        _setAllNextCells(_next, _size_x, _size_y);
    }
    void movesnake(int direction, bool game_over){
        // moves Cell in given direction
        _moveCell(direction, game_over, _size_x, _size_y, _next, _head, _body, _tail, _size_body, _food, _last_direction);
        // updates Current model
        _evolveCurrent(_current, _next, _size_x, _size_y);

    }

    void clearAllCells() {
        // sets all cells to 0, called in GameWidget::clear()
        _clearGrid(_current, _size_x, _size_y);
        // Next model is updated accordingly
        _setAllNextCells(_next, _size_x, _size_y);
    }

    // public Getters

    bool cellIsAlive(int xCoord, int yCoord) {
        // Called in GameWidget::paintUniverse,
        // checks living cells and updates widget grid view accordingly
        int cell = xCoord + yCoord * _size_x;
        if (_current[cell] == 1) {
            return true;
        } else{
            return false;
        }
    }


    int* get_current() {
        // returns current array
        return _current;
    }


    int* get_next() {
        // for debugging purposes only
        return _next;
    }


    int get_size() {
        // returns current grid size (of square grid)
        return _size_x;
    }


    int get_neighbours(int cell_x, int cell_y) {
        // counts and returns neighbours of given cell
        int cell = cell_x + _size_x*cell_y;
        return _getNeighbours(_current, cell, _size_x, _size_y);
    }


private:
    // universe size
    int _size_x;
    int _size_y;
    // universe model
    int* _current;
    int* _next;
    // universe view
    char* _currentView;
    char* _nextView;
    //snake
    int _head;
    int _size_body;
    int* _body;
    int _tail;
    int _food;
    int _last_direction;
    // private methods

    void _printGrid(char* grid, int size_x, int size_y) {
        // prints grid view
        //std::cout << "_printGrid called" << std::endl;
        for (int i = 0; i <= size_x+1; i++) {
            std::cout << ". ";
        }
        std::cout << std::endl;
        for (int i = 0; i < size_x * size_y; i++) {
            if(i == 0) {
                std::cout << ". ";
            }
            if (i % size_x == 0 && i>0) {
                std::cout << "." << std::endl << ". ";
            }
            std::cout << grid[i] << " ";
        }
        std::cout << "." << std::endl;
        for (int i = 0; i <= size_x+1; i++) {
            std::cout << ". ";
        }
        std::cout << std::endl;
    }


    void _resizeGrid(int* &grid, char* &grid_view, int Nx, int Ny) {
        // de-/increase current grid size
        //std::cout << "_resize called" << std::endl;
        int* temp = new int[Nx * Ny];
        char* temp_view = new char[Nx * Ny];
        if (Nx * Ny > _size_x * _size_y) {          // if increase size
            for (int i=0; i < Nx*Ny; i++) {
                temp[i] = 0;
                temp_view[i] = ' ';
            }
            for (int j=0; j < _size_y; j++) {
                for (int i=0; i < _size_x; i++) {
                    temp[i + j*Nx] = grid[i + j*_size_x];
                    temp_view[i + j*Nx] = grid_view[i + j*_size_x];
                }
            }
        } else {                                    // if decrease size
            for (int j = 0; j < Ny; j++) {
                for (int i = 0; i < Nx; i++) {
                    temp[i + j*Nx] = grid[i + j*_size_x];
                    temp_view[i + j*Nx] = grid_view[i + j*_size_x];
                }
            }
        }

        delete [] grid;
        grid = temp;

        delete [] grid_view;
        grid_view = temp_view;
    }


    // private Getters

    void _getView(char *&grid_view, int *grid, int Nx, int Ny) {
        // updates grid view from grid model
        //std::cout << "_getView called" << std::endl;
        char* temp = new char[Nx * Ny];
        for (int i = 0; i < Nx * Ny; i++) {
            temp[i] = grid[i] == 0 ? ' ' : '*';
        }

        delete[] grid_view;
        grid_view = temp;
    }


    int _getNeighbours(int* grid, int cell, int size_x, int size_y) {
        // iterates and counts living neighbours of given cell
        // ternary operator '?' handles boundary checks
        int neighbours = 0;

        for (int dim_x = (cell%size_x != 0 ? -1 : 0); dim_x <= (cell%size_x < (size_x-1) ? 1 : 0); dim_x++) {
            for (int dim_y = (cell/size_y != 0 ? -1 : 0); dim_y <= (cell/size_y < (size_y-1) ? 1 : 0); dim_y++) {
                if (dim_x != 0 || dim_y != 0) {
                    neighbours += grid[cell + dim_x + dim_y*_size_y];
                }
            }

        }
        return neighbours;
    }


    //private Setters

    void _setAliveCurrentCell(int* &grid, int cell) {
        // sets given cell to 'alive'
        //std::cout << "_populateCell called" << std::endl;
        grid[cell] = 1;
    }


    void _setNextCell(int* &next_grid, int* curr_grid, int cell, int neighbours) {
        //std::cout << "_setCell called" << std::endl;
        // computes state of given cell in next evolution step according to game rules
        switch(neighbours) {
        case 2:
            next_grid[cell] = curr_grid[cell] == 1 ? 1 : 0;
            break;
        case 3: next_grid[cell] = 1;
            break;
        default:
            next_grid[cell] = 0;
            break;
        }
    }


    void _setAllNextCells(int* &grid, int size_x, int size_y) {
        //std::cout << "_setNext called" << std::endl;
        // computes state of all cells in next evolution step according to game rules
        for(int i=0; i < size_x * size_y; i++){
            int neighbours = _getNeighbours(_current, i, size_x, size_y);
            _setNextCell(grid, _current, i, neighbours);
        }
    }


    void _evolveCurrent(int* &curr_grid, int* next_grid, int size_x, int size_y) {
        //std::cout << "_updateCurrent called" << std::endl;
        // overwrites current grid model with next grid model
        int* temp = new int[size_x * size_y];
        for (int i=0; i < size_x*size_y; i++) {
            temp[i] = next_grid[i];
        }
        delete [] curr_grid;
        curr_grid = temp;
    }

    void _clearGrid(int* &grid, int size_x, int size_y) {
        for (int cell = 0; cell< size_x*size_y; cell++) {
            grid[cell] = 0;
        }
    }

    void _moveCell(int direction, bool &game_over, int x, int y, int* &next_grid, int head, int* body, int tail, int size_body, int &food, int &last_direction){
        int new_head;
        int* new_body = new int[size_body];
        int new_tail;
        int new_food;
        bool food_place = false;
        bool moved = true;

        //moves Cell depending on given number
        switch(direction){

        case 8: //down
            //checks if you can move in the given direction
            if(last_direction!=2){
                //checks if snake is moving against the wall
                if(head-x>=0){
                    new_head = head-x;
                    last_direction = 8;
                }else{
                    game_over = true;
                }
            }else{
                moved = false;
            }
            break;

        case 2: //up
            //checks if you can move in the given direction
            if(last_direction!=8){
                //checks if snake is moving against the wall
                if(head+1<= x*y){
                    new_head = head+x;
                    last_direction = 2;
                }else{
                    game_over = true;
                }
            }else{
                moved = false;
            }
            break;

        case 6: //right
            //checks if you can move in the given direction
            if(last_direction!=4){
                //checks if snake is moving against the wall
                if(head%x!=x-1){
                    new_head = head+1;
                    last_direction = 6;
                }else{
                    game_over = true;
                }
            }else{
                moved = false;
            }
            break;

        case 4: //left
            //checks if you can move in the given direction
            if(last_direction!=6){
                //checks if snake is moving against the wall
                if(head%x!=0){
                    new_head = head-1;
                    last_direction = 4;
                }else{
                    game_over = true;
                }
            }else{
                moved = false;
            }
            break;


        }
        //when direction was legal the head was moved and moved is true, so the rest of the body will be moved too now
        if(moved){
        new_body[0] = head;
        new_tail = body[size_body];

        //moves body
        for(int i = 1; i <= size_body; i++){
            new_body[i]=body[i-1];
            next_grid[new_body[i]]=1;
           }


        //checks if snake isn't moving into itself
        for(int i=0; i<=size_body; i++){
            if(new_head == body[i]){
                game_over = true;
            }
        }
        if (new_head == tail){
            game_over = true;
        }

        //snake eats the food when head hits food
        if(new_head==food){
            size_body++;
            std::cout<< size_body << std::endl;
            new_body[size_body] = new_tail;
            std::cout << new_body[size_body-1] << std::endl;
            std::cout << new_body[size_body] << std::endl;
            new_tail = tail;

            //sets new food and checks if the food isn't placed on the snake
            do {
            srand( time(NULL) );
            new_food = rand() % (x*y);
            if (new_food != new_head && new_food != new_tail){
                for(int i=0; i<=size_body; i++){
                    if(new_food != new_body[i]){
                        food_place = true;
                    }
                    }
                }
            }while(food_place == false);
            food = new_food;

        }

        next_grid[new_body[0]] = 1;
        next_grid[new_head] = 1;
        next_grid[new_tail] = 1;
        next_grid[food] = 1;

        next_grid[tail]=0;
       _body = new_body;
       _head = new_head;
       _tail = new_tail;
       _size_body = size_body;
       }

    }

};

#endif // SNAKE_H
