#include <QtWidgets>

#include <QMouseEvent>
#include "gamewidget.h"
#include <iostream>
#include <QFrame>
#include <QPainter>
#include "cabase.h"
#include "snake.h"

// Constructor
GameWidget::GameWidget(QWidget *parent) :
QWidget(parent),
universeSize(30),
ca1(new CAbase(universeSize, universeSize)),
timer(new QTimer(this))
//, snake(new Snake())
{
    // some defaults
    setAttribute(Qt::WA_StaticContents);
    drawing = false;
    modified = false; // this serves currently no purpose
//    snakeMode = false;
    timer->setInterval(100);
    connect(timer, SIGNAL(timeout()), this, SLOT(newGeneration()));
//    setFocusPolicy(Qt::StrongFocus);


}

void GameWidget::paintEvent(QPaintEvent *)
{
    // gets reset every turn, the changes are stored in cabase object
    QPainter p(this);

    int cellWidth = width()/universeSize;
    int cellHeight = height()/universeSize;
    int gridWidth = universeSize*cellWidth - 1;
    int gridHeight = universeSize*cellHeight - 1;

    QRect rect(0 ,0 , gridWidth, gridHeight);

    paintGrid(p,rect, gridWidth, gridHeight, cellWidth, cellHeight);
    paintUniverse(p, ca1);
}

void GameWidget::paintGrid(QPainter &p, QRect &rect, int gridWidth, int gridHeight, int cellWidth, int cellHeight)
{
    // draws grid on QRect object in paintevent
    QColor gridColor = m_defaultColor;
    p.setPen(gridColor);
    for(int k = cellWidth; k <= gridWidth; k += cellWidth)
        p.drawLine(k, 0, k, gridHeight);

    for(int k = cellHeight; k <= gridHeight; k += cellHeight)
        p.drawLine(0, k, gridWidth, k);
    p.drawRect(rect);
}

void GameWidget::paintCell(const QPoint &lastCell)
{
    // width/height, although declared in paintevent AND as private attributes,
    // have to either be passed as arguments or declared within function in order to make this work...
    int cellWidth = width()/universeSize;
    int cellHeight = height()/universeSize;

    int xCoord = currentCell.x() / cellWidth;
    int yCoord = currentCell.y() / cellHeight;

    // triggered on mouse press/move, this function doesn't paint anything
    // but translates cursor position in widget to cabase coordinates,
    // setting given cells in cabase object to 'alive'
    if (drawing)
    {
        ca1->setAliveCell(xCoord, yCoord);
    }
    modified = true;
    currentCell = lastCell; // this here is crucial in order to paint multiple cells...

    update();
}

void GameWidget::paintUniverse(QPainter &p, CAbase *cabase)
{
    // again, these two need to be declared herein to make this work...
    int cellWidth = width()/universeSize;
    int cellHeight = height()/universeSize;

    QColor pencolor = m_defaultColor;
    p.setPen(pencolor);
    p.setBrush(pencolor);

    // checks each cabase cell, and fills grid view accordingly
    // iterates through entire *array for each update, so not super efficient...
    for (int x = 0; x<universeSize; x++){
        for (int y = 0; y<universeSize; y++) {
            if (ca1->cellIsAlive(x, y)) {
                int xCoord = x * cellWidth;
                int yCoord = y * cellHeight;
                p.fillRect(xCoord, yCoord, cellWidth, cellHeight, pencolor);
            }
        }
    }
    update();


}


QColor GameWidget::defaultColor()
{
    //get default color
    return m_defaultColor;
}

void GameWidget::setdefaultColor(const QColor &color)
{
    // set default color
    m_defaultColor = color;
    update();
}

void GameWidget::mousePressEvent(QMouseEvent *event)
{
    // enables "drawing"
    if (event->button() == Qt::LeftButton) {
        currentCell = event->pos();
        drawing = true;
    }
}

void GameWidget::mouseMoveEvent(QMouseEvent *event)
{
    // triggers "painting" while left button clicked
    if ((event->buttons() & Qt::LeftButton) && drawing)
        paintCell(event->pos());
}

void GameWidget::mouseReleaseEvent(QMouseEvent *event)
{
    // disables "drawing"
    if (event->button() == Qt::LeftButton && drawing) {
        paintCell(event->pos());
        drawing = false;
    }
}


void GameWidget::startGame() {
    // triggers timer event
    timer->start();

}

void GameWidget::stopGame() {
    // stops timer event
    timer->stop();

}

void GameWidget::clear(){
    // set all cabase cells to 'dead'
    timer->stop();
    ca1->clearAllCells();
}

void GameWidget::newGeneration(){
    // calls cabase evolve function
    ca1->evolveGrid();

}

void GameWidget::setTimerInterval(int interval){
    // sets timer interval
    timer->setInterval(interval);

}


void GameWidget::setUniverseSize(int newSize){
    // calls cabase resize function
    universeSize = newSize;
    ca1->resizeGrid(universeSize, universeSize);

}

void GameWidget::saveToFile(QFile &file)
{
    // save current universe size and state of cabase array to file
    int currentSize = universeSize;
    QString currentUniverseSize = QString::number(currentSize);
    int* currentState = ca1->get_current();
    QDataStream out(&file);
    out.setVersion(QDataStream::Qt_4_5);
    out << QString(currentUniverseSize);
    for (int x=0; x<universeSize*universeSize; x++) {
        out << (qint32)currentState[x];
    }
}


void GameWidget::loadFromFile(QFile &file)
{
    // overwrite universe size and current state with load data

    ca1->clearAllCells();   // clear existing cabase state

    QDataStream in(&file);
    in.setVersion(QDataStream::Qt_4_5);


    QString loadUniverseSize; // gets assigned to stored size

    in >> loadUniverseSize;
    setUniverseSize(loadUniverseSize.toInt()); // size is overwritten

    qint32* loadCurrentState = new qint32[universeSize*universeSize]; // assignment of stored cabase

    for (int x=0; x<universeSize*universeSize; x++) {
        in >> loadCurrentState[x];
    }

    //cabase state is restored, cell by cell
    for (int x = 0; x < universeSize; x++){
        for (int y = 0; y < universeSize; y++){
            if ((int)loadCurrentState[x+y*universeSize] == 1) {
                ca1->setAliveCell(x, y);
            }
        }
    }
    update();

}

int GameWidget::getUniverseSize()
{
    // needed to assign universeSize to respective spinbox after loading file
    return universeSize;
}

void GameWidget::changeGame()
{
    stopGame();
    clear();
    update();
}
