#include <QTextStream>
#include <QFileDialog>
#include <QDebug>
#include <QColor>
#include <QColorDialog>
#include <QStackedLayout>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QProcess>
#include <iostream>
#include <string>
#include "gamewidget.h"
#include "snakewidget.h"

#include <QDebug> // zum testen (z.b. Ausgaben in Qt Console erzeugen)

MainWindow::MainWindow(QWidget *parent) :
QMainWindow(parent)
, ui(new Ui::MainWindow)
, game(new GameWidget(this))
, snakegame(new SnakeWidget(this))

{
    ui->setupUi(this);
    ui->mainLayout->setStretchFactor(ui->gameLayout, 8);
    QPixmap icon(16, 16);
    icon.fill(game->defaultColor());
    ui->gameLayout->addWidget(game);
    ui->pushButton_select_color->setIcon( QIcon(icon) );

    on_comboBox_universe_mode_currentIndexChanged(ui->comboBox_universe_mode->currentText());

};

MainWindow::~MainWindow()
{
    delete ui;
}

//select game mode
void MainWindow::on_comboBox_universe_mode_currentIndexChanged(const QString)
{
    if (ui->comboBox_universe_mode->currentText() == "Snake")
    {
        ui->gameLayout->removeWidget(game);
        ui->gameLayout->addWidget(snakegame);


        connect(ui->pushButton_clear, SIGNAL(clicked()),snakegame,SLOT(clear()));

        connect(ui->spinBox_universe_size, SIGNAL(valueChanged(int)), snakegame, SLOT(setUniverseSize(int)));

        connect(ui->pushButton_start, SIGNAL(clicked()),snakegame,SLOT(startGame()));

        connect(ui->pushButton_stop, SIGNAL(clicked()),snakegame,SLOT(stopGame()));

        connect(ui->spinBox_generation_interval, SIGNAL(valueChanged(int)), snakegame, SLOT(setTimerInterval(int)));

        connect(ui->comboBox_universe_mode, SIGNAL(currentIndexChanged(int)), snakegame, SLOT(changeGame()));
    }

    else if (ui->comboBox_universe_mode->currentText() == "Game of Life")
    {
        ui->gameLayout->removeWidget(snakegame);
        ui->gameLayout->addWidget(game);

        connect(ui->pushButton_clear, SIGNAL(clicked()),game,SLOT(clear()));

        connect(ui->spinBox_universe_size, SIGNAL(valueChanged(int)), game, SLOT(setUniverseSize(int)));

        connect(ui->pushButton_start, SIGNAL(clicked()),game,SLOT(startGame()));

        connect(ui->pushButton_stop, SIGNAL(clicked()),game,SLOT(stopGame()));

        connect(ui->spinBox_generation_interval, SIGNAL(valueChanged(int)), game, SLOT(setTimerInterval(int)));

        connect(ui->comboBox_universe_mode, SIGNAL(currentIndexChanged(int)), game, SLOT(changeGame()));

    }
}


// most of these seem to be currently placeholders
void MainWindow::on_spinBox_generation_interval_valueChanged(int interval)
{
    qDebug() << interval;

}

void MainWindow::on_pushButton_start_clicked()
{
    qDebug() << "Start";
}

void MainWindow::on_pushButton_stop_clicked()
{
    qDebug() << "Stop";
}

void MainWindow::on_pushButton_clear_clicked()
{
    qDebug() << "Clear";
}

void MainWindow::on_spinBox_universe_size_valueChanged(int size)
{
    qDebug() << size;
}

void MainWindow::on_pushButton_select_color_clicked()
{
    // set cell color
    game->stopGame();
    QColor color = QColorDialog::getColor(currentColor, this);
    if(!color.isValid())
        return;
    currentColor = color;
    game->setdefaultColor(color);
    QPixmap icon(16, 16);
    icon.fill(color);
    ui->pushButton_select_color->setIcon( QIcon(icon) );
}

void MainWindow::on_pushButton_random_color_clicked()
{
    //this is incomplete
    game->stopGame();
    QColor color = QColorDialog::getColor();
    ui->pushButton_random_color->setPalette(color);
}

void MainWindow::on_pushButton_go_clicked()
{
    qDebug() << "GO!";
}


void MainWindow::on_pushButton_save_clicked()
{
    // open save dialog
    game->stopGame();
    QString fileName = QFileDialog::getSaveFileName(this,
                        tr("Save Current Universe"), "",
                        tr("Cellular Automata (*.ca);;All Files (*)"));
    if (fileName.isEmpty()) {
        return;
    } else {
        QFile file(fileName);
        if (!file.open(QIODevice::WriteOnly)) {
            QMessageBox::information(this, tr("Unable to open file"),
                                     file.errorString());
            return;
        }
        // save current universe size and state
        game->saveToFile(file);
    }
}

void MainWindow::on_pushButton_load_clicked()
{
    // opens load dialog
    game->stopGame();
    QString fileName = QFileDialog::getOpenFileName(this,
        tr("Open Existing Universe"), "",
        tr("Cellular Automata (*.ca);;All Files (*)"));
    if (fileName.isEmpty()) {
        return;
    } else {

        QFile file(fileName);

        if (!file.open(QIODevice::ReadOnly)) {
            QMessageBox::information(this, tr("Unable to open file"),
                                     file.errorString());
            return;
        }
        // overwrite current universe size and state
        game->loadFromFile(file);
        ui->spinBox_universe_size->setValue(game->getUniverseSize());
    }
}


