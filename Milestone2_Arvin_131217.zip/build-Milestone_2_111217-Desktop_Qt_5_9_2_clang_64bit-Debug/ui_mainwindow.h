/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStackedLayout>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QVBoxLayout *horizontalLayout;
    QHBoxLayout *mainLayout;
    QStackedLayout *gameLayout;
    QVBoxLayout *setLayout;
    QHBoxLayout *controlLayout;
    QPushButton *pushButton_start;
    QPushButton *pushButton_stop;
    QPushButton *pushButton_clear;
    QLabel *label_uiverse_size;
    QSpinBox *spinBox_universe_size;
    QLabel *label_universe_mode;
    QComboBox *comboBox_universe_mode;
    QLabel *label_cells_mode;
    QComboBox *comboBox_cells_mode;
    QLabel *label_generation_interval;
    QSpinBox *spinBox_generation_interval;
    QHBoxLayout *horizontalLayout1;
    QPushButton *pushButton_load;
    QPushButton *pushButton_save;
    QPushButton *pushButton_select_color;
    QPushButton *pushButton_random_color;
    QPushButton *pushButton_go;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->setEnabled(true);
        MainWindow->resize(679, 480);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        horizontalLayout = new QVBoxLayout(centralWidget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        mainLayout = new QHBoxLayout();
        mainLayout->setSpacing(6);
        mainLayout->setObjectName(QStringLiteral("mainLayout"));
        gameLayout = new QStackedLayout();
        gameLayout->setSpacing(6);
        gameLayout->setObjectName(QStringLiteral("gameLayout"));

        mainLayout->addLayout(gameLayout);

        setLayout = new QVBoxLayout();
        setLayout->setSpacing(6);
        setLayout->setObjectName(QStringLiteral("setLayout"));
        controlLayout = new QHBoxLayout();
        controlLayout->setSpacing(6);
        controlLayout->setObjectName(QStringLiteral("controlLayout"));
        pushButton_start = new QPushButton(centralWidget);
        pushButton_start->setObjectName(QStringLiteral("pushButton_start"));
        pushButton_start->setMinimumSize(QSize(74, 32));
        pushButton_start->setMaximumSize(QSize(74, 32));

        controlLayout->addWidget(pushButton_start);

        pushButton_stop = new QPushButton(centralWidget);
        pushButton_stop->setObjectName(QStringLiteral("pushButton_stop"));
        pushButton_stop->setMinimumSize(QSize(74, 32));
        pushButton_stop->setMaximumSize(QSize(74, 32));

        controlLayout->addWidget(pushButton_stop);

        pushButton_clear = new QPushButton(centralWidget);
        pushButton_clear->setObjectName(QStringLiteral("pushButton_clear"));
        pushButton_clear->setMinimumSize(QSize(74, 32));
        pushButton_clear->setMaximumSize(QSize(74, 32));

        controlLayout->addWidget(pushButton_clear);


        setLayout->addLayout(controlLayout);

        label_uiverse_size = new QLabel(centralWidget);
        label_uiverse_size->setObjectName(QStringLiteral("label_uiverse_size"));

        setLayout->addWidget(label_uiverse_size);

        spinBox_universe_size = new QSpinBox(centralWidget);
        spinBox_universe_size->setObjectName(QStringLiteral("spinBox_universe_size"));
        spinBox_universe_size->setMinimumSize(QSize(220, 24));
        spinBox_universe_size->setMaximumSize(QSize(220, 24));
        spinBox_universe_size->setMinimum(2);
        spinBox_universe_size->setMaximum(50);
        spinBox_universe_size->setValue(30);

        setLayout->addWidget(spinBox_universe_size);

        label_universe_mode = new QLabel(centralWidget);
        label_universe_mode->setObjectName(QStringLiteral("label_universe_mode"));

        setLayout->addWidget(label_universe_mode);

        comboBox_universe_mode = new QComboBox(centralWidget);
        comboBox_universe_mode->setObjectName(QStringLiteral("comboBox_universe_mode"));
        comboBox_universe_mode->setMinimumSize(QSize(226, 26));
        comboBox_universe_mode->setMaximumSize(QSize(226, 26));

        setLayout->addWidget(comboBox_universe_mode);

        label_cells_mode = new QLabel(centralWidget);
        label_cells_mode->setObjectName(QStringLiteral("label_cells_mode"));

        setLayout->addWidget(label_cells_mode);

        comboBox_cells_mode = new QComboBox(centralWidget);
        comboBox_cells_mode->setObjectName(QStringLiteral("comboBox_cells_mode"));
        comboBox_cells_mode->setMinimumSize(QSize(226, 26));
        comboBox_cells_mode->setMaximumSize(QSize(226, 26));

        setLayout->addWidget(comboBox_cells_mode);

        label_generation_interval = new QLabel(centralWidget);
        label_generation_interval->setObjectName(QStringLiteral("label_generation_interval"));

        setLayout->addWidget(label_generation_interval);

        spinBox_generation_interval = new QSpinBox(centralWidget);
        spinBox_generation_interval->setObjectName(QStringLiteral("spinBox_generation_interval"));
        spinBox_generation_interval->setMinimumSize(QSize(220, 24));
        spinBox_generation_interval->setMaximumSize(QSize(220, 24));
        spinBox_generation_interval->setButtonSymbols(QAbstractSpinBox::PlusMinus);
        spinBox_generation_interval->setAccelerated(false);
        spinBox_generation_interval->setMinimum(100);
        spinBox_generation_interval->setMaximum(1000);
        spinBox_generation_interval->setSingleStep(100);
        spinBox_generation_interval->setValue(100);
        spinBox_generation_interval->setDisplayIntegerBase(10);

        setLayout->addWidget(spinBox_generation_interval);

        horizontalLayout1 = new QHBoxLayout();
        horizontalLayout1->setSpacing(6);
        horizontalLayout1->setObjectName(QStringLiteral("horizontalLayout1"));
        pushButton_load = new QPushButton(centralWidget);
        pushButton_load->setObjectName(QStringLiteral("pushButton_load"));
        pushButton_load->setMinimumSize(QSize(112, 32));
        pushButton_load->setMaximumSize(QSize(112, 32));

        horizontalLayout1->addWidget(pushButton_load);

        pushButton_save = new QPushButton(centralWidget);
        pushButton_save->setObjectName(QStringLiteral("pushButton_save"));
        pushButton_save->setMinimumSize(QSize(112, 32));
        pushButton_save->setMaximumSize(QSize(112, 32));

        horizontalLayout1->addWidget(pushButton_save);


        setLayout->addLayout(horizontalLayout1);

        pushButton_select_color = new QPushButton(centralWidget);
        pushButton_select_color->setObjectName(QStringLiteral("pushButton_select_color"));
        pushButton_select_color->setEnabled(true);
        pushButton_select_color->setMinimumSize(QSize(226, 32));
        pushButton_select_color->setMaximumSize(QSize(226, 32));
        pushButton_select_color->setAutoDefault(false);
        pushButton_select_color->setFlat(false);

        setLayout->addWidget(pushButton_select_color, 0, Qt::AlignHCenter);

        pushButton_random_color = new QPushButton(centralWidget);
        pushButton_random_color->setObjectName(QStringLiteral("pushButton_random_color"));
        pushButton_random_color->setEnabled(true);

        setLayout->addWidget(pushButton_random_color);

        pushButton_go = new QPushButton(centralWidget);
        pushButton_go->setObjectName(QStringLiteral("pushButton_go"));

        setLayout->addWidget(pushButton_go);


        mainLayout->addLayout(setLayout);


        horizontalLayout->addLayout(mainLayout);

        MainWindow->setCentralWidget(centralWidget);

        retranslateUi(MainWindow);

        pushButton_select_color->setDefault(false);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Cellular Automata", Q_NULLPTR));
        pushButton_start->setText(QApplication::translate("MainWindow", "Start", Q_NULLPTR));
        pushButton_stop->setText(QApplication::translate("MainWindow", "Stop", Q_NULLPTR));
        pushButton_clear->setText(QApplication::translate("MainWindow", "Clear", Q_NULLPTR));
        label_uiverse_size->setText(QApplication::translate("MainWindow", "Universe Size", Q_NULLPTR));
        label_universe_mode->setText(QApplication::translate("MainWindow", "Universe Mode", Q_NULLPTR));
        comboBox_universe_mode->clear();
        comboBox_universe_mode->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Game of Life", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Snake", Q_NULLPTR)
        );
        label_cells_mode->setText(QApplication::translate("MainWindow", "Cells Mode", Q_NULLPTR));
        comboBox_cells_mode->clear();
        comboBox_cells_mode->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Classic", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Night", Q_NULLPTR)
        );
        label_generation_interval->setText(QApplication::translate("MainWindow", "Generation interval (in msec)", Q_NULLPTR));
        pushButton_load->setText(QApplication::translate("MainWindow", "Load", Q_NULLPTR));
        pushButton_save->setText(QApplication::translate("MainWindow", "Save", Q_NULLPTR));
        pushButton_select_color->setText(QApplication::translate("MainWindow", "Select Color", Q_NULLPTR));
        pushButton_random_color->setText(QApplication::translate("MainWindow", "Random Color", Q_NULLPTR));
        pushButton_go->setText(QApplication::translate("MainWindow", "GO!", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
