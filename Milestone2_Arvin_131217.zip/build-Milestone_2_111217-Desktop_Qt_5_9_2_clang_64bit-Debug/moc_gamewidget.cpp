/****************************************************************************
** Meta object code from reading C++ file 'gamewidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../Milestone_2_111217/gamewidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'gamewidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_GameWidget_t {
    QByteArrayData data[33];
    char stringdata0[323];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GameWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GameWidget_t qt_meta_stringdata_GameWidget = {
    {
QT_MOC_LITERAL(0, 0, 10), // "GameWidget"
QT_MOC_LITERAL(1, 11, 10), // "saveToFile"
QT_MOC_LITERAL(2, 22, 0), // ""
QT_MOC_LITERAL(3, 23, 6), // "QFile&"
QT_MOC_LITERAL(4, 30, 4), // "file"
QT_MOC_LITERAL(5, 35, 12), // "loadFromFile"
QT_MOC_LITERAL(6, 48, 9), // "startGame"
QT_MOC_LITERAL(7, 58, 8), // "stopGame"
QT_MOC_LITERAL(8, 67, 5), // "clear"
QT_MOC_LITERAL(9, 73, 13), // "newGeneration"
QT_MOC_LITERAL(10, 87, 16), // "setTimerInterval"
QT_MOC_LITERAL(11, 104, 8), // "interval"
QT_MOC_LITERAL(12, 113, 15), // "setUniverseSize"
QT_MOC_LITERAL(13, 129, 7), // "newSize"
QT_MOC_LITERAL(14, 137, 12), // "defaultColor"
QT_MOC_LITERAL(15, 150, 15), // "setdefaultColor"
QT_MOC_LITERAL(16, 166, 5), // "color"
QT_MOC_LITERAL(17, 172, 15), // "getUniverseSize"
QT_MOC_LITERAL(18, 188, 10), // "changeGame"
QT_MOC_LITERAL(19, 199, 9), // "paintGrid"
QT_MOC_LITERAL(20, 209, 9), // "QPainter&"
QT_MOC_LITERAL(21, 219, 1), // "p"
QT_MOC_LITERAL(22, 221, 6), // "QRect&"
QT_MOC_LITERAL(23, 228, 4), // "rect"
QT_MOC_LITERAL(24, 233, 9), // "gridWidth"
QT_MOC_LITERAL(25, 243, 10), // "gridHeight"
QT_MOC_LITERAL(26, 254, 9), // "cellWidth"
QT_MOC_LITERAL(27, 264, 10), // "cellHeight"
QT_MOC_LITERAL(28, 275, 9), // "paintCell"
QT_MOC_LITERAL(29, 285, 8), // "lastCell"
QT_MOC_LITERAL(30, 294, 13), // "paintUniverse"
QT_MOC_LITERAL(31, 308, 7), // "CAbase*"
QT_MOC_LITERAL(32, 316, 6) // "cabase"

    },
    "GameWidget\0saveToFile\0\0QFile&\0file\0"
    "loadFromFile\0startGame\0stopGame\0clear\0"
    "newGeneration\0setTimerInterval\0interval\0"
    "setUniverseSize\0newSize\0defaultColor\0"
    "setdefaultColor\0color\0getUniverseSize\0"
    "changeGame\0paintGrid\0QPainter&\0p\0"
    "QRect&\0rect\0gridWidth\0gridHeight\0"
    "cellWidth\0cellHeight\0paintCell\0lastCell\0"
    "paintUniverse\0CAbase*\0cabase"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GameWidget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   89,    2, 0x0a /* Public */,
       5,    1,   92,    2, 0x0a /* Public */,
       6,    0,   95,    2, 0x0a /* Public */,
       7,    0,   96,    2, 0x0a /* Public */,
       8,    0,   97,    2, 0x0a /* Public */,
       9,    0,   98,    2, 0x0a /* Public */,
      10,    1,   99,    2, 0x0a /* Public */,
      12,    1,  102,    2, 0x0a /* Public */,
      14,    0,  105,    2, 0x0a /* Public */,
      15,    1,  106,    2, 0x0a /* Public */,
      17,    0,  109,    2, 0x0a /* Public */,
      18,    0,  110,    2, 0x0a /* Public */,
      19,    6,  111,    2, 0x08 /* Private */,
      28,    1,  124,    2, 0x08 /* Private */,
      30,    2,  127,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   11,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::QColor,
    QMetaType::Void, QMetaType::QColor,   16,
    QMetaType::Int,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 20, 0x80000000 | 22, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,   21,   23,   24,   25,   26,   27,
    QMetaType::Void, QMetaType::QPoint,   29,
    QMetaType::Void, 0x80000000 | 20, 0x80000000 | 31,   21,   32,

       0        // eod
};

void GameWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        GameWidget *_t = static_cast<GameWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->saveToFile((*reinterpret_cast< QFile(*)>(_a[1]))); break;
        case 1: _t->loadFromFile((*reinterpret_cast< QFile(*)>(_a[1]))); break;
        case 2: _t->startGame(); break;
        case 3: _t->stopGame(); break;
        case 4: _t->clear(); break;
        case 5: _t->newGeneration(); break;
        case 6: _t->setTimerInterval((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->setUniverseSize((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: { QColor _r = _t->defaultColor();
            if (_a[0]) *reinterpret_cast< QColor*>(_a[0]) = std::move(_r); }  break;
        case 9: _t->setdefaultColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 10: { int _r = _t->getUniverseSize();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 11: _t->changeGame(); break;
        case 12: _t->paintGrid((*reinterpret_cast< QPainter(*)>(_a[1])),(*reinterpret_cast< QRect(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])),(*reinterpret_cast< int(*)>(_a[5])),(*reinterpret_cast< int(*)>(_a[6]))); break;
        case 13: _t->paintCell((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 14: _t->paintUniverse((*reinterpret_cast< QPainter(*)>(_a[1])),(*reinterpret_cast< CAbase*(*)>(_a[2]))); break;
        default: ;
        }
    }
}

const QMetaObject GameWidget::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_GameWidget.data,
      qt_meta_data_GameWidget,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *GameWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GameWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_GameWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int GameWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 15;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
