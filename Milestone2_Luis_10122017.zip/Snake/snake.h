#ifndef SNAKE_H
#define SNAKE_H

class Snake{

public:

    Snake(int Nx, int Ny){
        /* - Nx and Ny for grid size
         * - dynamic integer array for grid
         *   (Cell: 0 -> empty, 1 -> head, 2 -> body, 3 -> tail, 4 -> food)*/

        _size_x = Nx;
        _size_y = Ny;
        _length = 1; // length of body
        _grid = new int[Nx * Ny];


        // fill grid with zeros
        for (int i = 0; i < (Nx * Ny); i++){
                _grid[i] = 0;
        }
    }

    ~Snake(){
        delete[] _grid;
    }

    bool move(){
        // Moves snake's head. Body and tail follow. Returns false, if snake crashs.
        // (2 – down, 8 - up, 4 - left, 6 – right)

        // get position of head
        int head_cell = _coordToCell(head.x, head.y);
        // delete head on grid
        _grid[head_cell] = 0;

        // in this part the pieces of the body must be handled
        /*
        section test = _body[0];
        int test_cell = _coordToCell(test.x, test.y);
        _grid[test_cell] = 0;
        test.x = head.x;
        test.y = head.y;
        _grid[head_cell] = 2;*/

        // tail
        int tail_cell = _coordToCell(tail.x, tail.y);
        _grid[tail_cell] = 0;
        tail.x = head.x;
        tail.y = head.y;
        _grid[head_cell] = 3;

        // moves head
        switch (_dir){
        case 2:
            if(head.y == _size_y-1){
                return false;
            } else {
                head.y++;
                _grid[head_cell+_size_x]=1;
            }
            break;
        case 8:
            if (head.y == 0){
                return false;
            } else {
                head.y--;
                _grid[head_cell-_size_x]=1;
            }
            break;
        case 4:
            if (head.x == 0){
                return false;
            } else {
                head.x--;
                _grid[head_cell-1]=1;
            }
            break;
        case 6:
            if (head.x == _size_x-1){
                return false;
            }else{
                head.x++;
                _grid[head_cell+1]=1;
            }
            break;
        }
        return true;
    }



    // --- Public Setters ---

    void setSnake(){
        // Places the snake in the middle of the grid.
        head.x = _size_x/2;
        head.y = _size_y/2;

        tail.x = _size_x/2;
        tail.y = _size_y/2+1;

        int cell_head = _coordToCell(_size_x/2, _size_y/2);
        _grid[cell_head] = 1;
        int cell_tail = _coordToCell(_size_x/2, _size_y/2 + 1);
        _grid[cell_tail] = 3;


        // in this part the pieces of the body must be handled
        /*
        section piece = _body[0];
        piece.x = _size_x/2;
        piece.y = _size_y/2+1;

        int cell_body = _coordToCell(_size_x/2, _size_y/2 + 1);
        _grid[cell_body] = 2;*/

    }

    void setFood(int x, int y){
        // Sets food on given coordinates.
        int cell = _coordToCell(x, y);
        _grid[cell] = 4;
    }

    void setDirection(int dir){
        // 2 – down, 8 - up, 4 - left, 6 – right)
        switch (dir){
        case 2: _dir = 2; break;
        case 8: _dir = 8; break;
        case 4: _dir = 4; break;
        case 6: _dir = 6; break;
        }
    }

    void clear(){
        // Clears the grid.
        for (int i = 0; i < (_size_x * _size_y); i++){
                _grid[i] = 0;
        }
    }



    // --- Public Getters ---

    int getGrid(){
    // missing
    // should return _grid
    }

    void print(){
        // Prints the grid on console. (For Console Tests only!)
        for (int i = 0; i <= _size_x+1; i++) {
            std::cout << ". ";
        }
        std::cout << std::endl;

        for (int i = 0; i < _size_x * _size_y; i++) {
            if(i == 0) {
                std::cout << ". ";
            }
            if (i % _size_x == 0 && i>0) {
                std::cout << "." << std::endl << ". ";
            }

            switch (_grid[i]){
            case 0: std::cout << "  "; break;
            case 1: std::cout << "O "; break;
            case 2: std::cout << "# "; break;
            case 3: std::cout << "# "; break;
            case 4: std::cout << "* "; break;
             }
        }
        std::cout << "." << std::endl;
        for (int i = 0; i <= _size_x+1; i++) {
            std::cout << ". ";
        }
        std::cout << std::endl;
    }


private:
    // --- Private Variables ---

    // Universe: Grid Size
    int _size_x;
    int _size_y;
    // Universe: Grid
    int* _grid;

    // Snake: Direction
    int _dir;
    // Snake: Length
    int _length;
    // Snake: Sections of Snake
    struct section {
        int x;
        int y;
    };
    section head;
    section tail;
    section* _body = new section[1];

    // Food
    int _food;



    // --- Private Getters ---

    int _getLower(int x_coord, int y_coord){
        // returns cell value (position in 1D array) of the lower element
        return _coordToCell(x_coord, y_coord+1);
    }

    int _getUpper(int x_coord, int y_coord){
        // returns cell value (position in 1D array) of the upper element
        return _coordToCell(x_coord, y_coord-1);
    }

    int _getLeft(int x_coord, int y_coord){
        // returns cell value (position in 1D array) of the left element
        return _coordToCell(x_coord-1, y_coord);
    }

    int _getRight(int x_coord, int y_coord){
        // returns cell value (position in 1D array) of the right element
        return _coordToCell(x_coord+1, y_coord);
    }


    int _coordToCell(int x, int y){
        // converts coordinates of an element to the position in 1-D array (called 'cell')
        return (y * _size_x + x);
    }

};
#endif // SNAKE_H
