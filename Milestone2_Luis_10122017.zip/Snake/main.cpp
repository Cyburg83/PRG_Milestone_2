#include <iostream>
#include <string>
#include "Snake.h"







int main() {
    Snake test(20, 20);
    test.setSnake();
    test.print();

    std::cout << "Auf korrekte Eingabe achten! Nur für Testzwecke!"
                 "" << std::endl;
    std::cout << "2 down, 8 up, 4 left, 6 right, 9 exit" << std::endl;

    int input = 0;

    while (input != 9) {
        std::cout << "Input: ";
        std::cin >> input;
        test.setDirection(input);
        if (false == test.move()){
            input = 9;
            std::cout << std::endl << "===========================" << std::endl;
            std::cout << "         Game Over!" << std::endl;
            std::cout << "===========================" << std::endl;
        }
        test.print();
    }

    test.~Snake();

    system("PAUSE");
    return 0;
}


/*
 *
    int input;
    std::cin >> input;

    switch (input){
    case 4:
        std::cout << "Test!" << std::endl;
        break;
    case 6:
        std::cout << "Test!" << std::endl;
        break;
    case 8:
        std::cout << "Test!" << std::endl;
        break;
    case 5:
        std::cout << "Test!" << std::endl;
        break;
    default:
        std::cout << "Error. Invalid input!" << std::endl;
        break;
    }
*/
