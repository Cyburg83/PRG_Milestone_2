﻿PRG Milestone 2 BETA Readme

*************************************************************

Version: BETA_PRG_Milestone_2_Wise17_Burg_Hohmann_Klemm_Matic

************************************************************* 
*** Autoren:
	* Burg, Andre
	* Hohmann, Luis
	* Klemm, Chantal
	* Matic, Arvin 

************************************************************* 
*** Ausführung:
	Die Lösungen zu Milestone 2 befinden sich als QT 
	Projekt in dem ZIP Archiv. Starten kann man das
	Projekt mit QT Creator.

************************************************************* 
*** Beschreibung:
	Da es im OLAT aufgrund eines Updates zu Fehlern
	kam (Stand 13.12.2017), haben wir diese Vorabversion
	erstellt und hochgeladen.
	* Ordner Milestone2_Konsole:
	  enthält Projekt "Snake". Das Snakespiel 
	  funktioniert, aber ohne GUI.
	
	*Ordner Milestone2_GUI:
	  enthält Projekt "Milestone_2_111217". Snake
	  befindet sich zwar im GUI, aber läuft noch nicht 
	  richtig.
	
*************************************************************
*** Wichtig:
	Sobald ein anderes Gruppenmitglied eine Version 
	hochlädt, gilt es diese Version zu ignorieren.
	Sie wurde nur erstellt, falls es zu Uploadproblemen
	heute abend kommen sollte!
*************************************************************